package com.nightguardian.app

import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var statusCard: TextView
    private lateinit var root: LinearLayout

    private val bg = Color.rgb(9, 14, 31)
    private val panel = Color.rgb(20, 29, 53)
    private val white = Color.rgb(242, 246, 255)
    private val muted = Color.rgb(164, 178, 207)
    private val blue = Color.rgb(92, 143, 255)
    private val green = Color.rgb(55, 210, 151)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScheduleManager.scheduleDaily(this)
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::statusCard.isInitialized) refreshStatus()
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 26, 22, 26)
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.rgb(14, 25, 54), bg)
            )
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val brand = text("☾  NIGHT GUARDIAN", 23f, white, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.06f
            setPadding(0, 10, 0, 8)
        }
        content.addView(brand, matchWrap())

        content.addView(text("Your peaceful night starts here", 14f, muted).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 22)
        }, matchWrap())

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 24, 20, 24)
            background = rounded(panel, 28f)
        }
        hero.addView(text("🌙", 48f, white).apply { gravity = Gravity.CENTER })
        hero.addView(text("10:00 PM  —  6:00 AM", 23f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 8)
        })
        hero.addView(text("DAILY AUTOMATIC SCHEDULE", 11f, muted, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        })
        content.addView(hero, matchWrap())

        statusCard = text("", 16f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(18, 18, 18, 18)
            background = rounded(Color.rgb(26, 48, 70), 20f)
        }
        val statusLp = matchWrap().apply { topMargin = 14 }
        content.addView(statusCard, statusLp)

        val section = text("SETUP YOUR PHONE", 12f, muted, true).apply {
            letterSpacing = 0.12f
            setPadding(4, 26, 4, 10)
        }
        content.addView(section, matchWrap())

        addAction(content, "01  Allow Do Not Disturb", "Silence calls and alerts") { openDndAccess() }
        addAction(content, "02  Enable app blocking", "Turn on Night Guardian in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addAction(content, "03  Allow exact alarms", "Help the 10 PM / 6 AM schedule run on time") {
            openExactAlarmSettings()
        }

        content.addView(text("QUICK CONTROLS", 12f, muted, true).apply {
            letterSpacing = 0.12f
            setPadding(4, 24, 4, 10)
        }, matchWrap())

        val schedule = makeButton("✓   SAVE DAILY SCHEDULE", blue)
        schedule.setOnClickListener {
            ScheduleManager.scheduleDaily(this)
            refreshStatus()
        }
        content.addView(schedule, matchWrap())

        val test = makeButton("TEST NIGHT MODE NOW", Color.rgb(43, 58, 88))
        test.setOnClickListener {
            NightMode.setEnabled(this, true)
            refreshStatus()
        }
        content.addView(test, matchWrap())

        val stop = makeButton("TURN NIGHT MODE OFF", Color.rgb(65, 48, 65))
        stop.setOnClickListener {
            NightMode.setEnabled(this, false)
            refreshStatus()
        }
        content.addView(stop, matchWrap())

        content.addView(text(
            "Safety first: Android system settings and the phone dialer remain accessible. " +
            "Do Not Disturb silences calls; it does not reject them. Emergency calls should remain available.",
            12f, muted
        ).apply { setPadding(6, 20, 6, 10); gravity = Gravity.CENTER }, matchWrap())

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)
        refreshStatus()
    }

    private fun addAction(parent: LinearLayout, title: String, subtitle: String, action: () -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            background = rounded(panel, 18f)
            setOnClickListener { action() }
        }
        card.addView(text(title, 16f, white, true))
        card.addView(text(subtitle, 12f, muted).apply { setPadding(0, 5, 0, 0) })
        parent.addView(card, matchWrap().apply { bottomMargin = 9 })
    }

    private fun makeButton(label: String, color: Int): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 14f
        setTextColor(Color.WHITE)
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        background = rounded(color, 18f)
        stateListAnimator = null
        minHeight = 54
        setPadding(12, 8, 12, 8)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)

    private fun openDndAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    private fun openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            })
        }
    }

    private fun refreshStatus() {
        val enabled = NightMode.isEnabled(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val dndActive = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
        statusCard.text =
            (if (enabled) "●  NIGHT MODE IS ON" else "○  NIGHT MODE IS OFF") +
            "\nDND: " + (if (dndActive) "Active" else "Not active") +
            "\nNext routine: 10:00 PM → 6:00 AM"
        statusCard.setTextColor(if (enabled) green else white)
    }
}
