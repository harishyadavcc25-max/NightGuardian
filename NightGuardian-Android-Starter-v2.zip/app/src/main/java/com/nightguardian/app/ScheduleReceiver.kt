package com.nightguardian.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NightMode.setEnabled(context, intent.getBooleanExtra("enable", false))
        ScheduleManager.scheduleDaily(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ScheduleManager.scheduleDaily(context)
            val active = NightMode.isEnabled(context)
            if (active) NightMode.setEnabled(context, true)
        }
    }
}
