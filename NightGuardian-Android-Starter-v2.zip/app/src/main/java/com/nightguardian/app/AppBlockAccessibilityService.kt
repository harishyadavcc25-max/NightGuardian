package com.nightguardian.app

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class AppBlockAccessibilityService : AccessibilityService() {
    // Keep essential system surfaces reachable to prevent accidental lockout.
    private val allowedPackages = setOf(
        "com.nightguardian.app",
        "com.android.systemui",
        "com.android.settings",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.android.dialer",
        "com.google.android.dialer",
        "com.android.phone"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !NightMode.isEnabled(this)) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in allowedPackages || pkg.startsWith("com.android.") && pkg.contains("systemui")) return
        // Return to Home instead of interacting with or closing another app.
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun onInterrupt() = Unit
}
