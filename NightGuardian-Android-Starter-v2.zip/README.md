# Night Guardian (Android starter)

Default schedule: daily 10:00 PM ON, 6:00 AM OFF.

## Build
1. Open this folder in Android Studio (recent stable version).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on your Android phone.

## First-time setup
1. Open Night Guardian.
2. Grant Do Not Disturb access.
3. Enable **Night Guardian app blocking** under Android Accessibility settings.
4. Allow exact alarms if Android asks.
5. Tap **Schedule 10 PM – 6 AM**.

## Behavior and limitations
- At 10 PM, the app sets Android Do Not Disturb to total silence and the accessibility service sends most third-party apps back to Home.
- At 6 AM, it disables the app's Night Mode and restores the phone's interruption filter to ALL.
- This does not reject calls or power off the phone; DND silences incoming calls and notifications.
- Android system screens, Settings, Night Guardian, and dialer surfaces are exempt so the device remains recoverable and emergency calling stays possible.
- Some manufacturers apply aggressive battery restrictions. Exempt Night Guardian from battery optimization if alarms are delayed.
- This is a starter project, not a Play Store-ready release. Test on your own device. Accessibility permission is powerful; enable it only for software you trust.
